import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class WorkingWithForms 
{
	public static void main(String[] args) throws InterruptedException 
	{
		
		WebDriver driver=new FirefoxDriver();//for browser
		driver.get("file:///D:/Lesson%205-HTML%20Pages/WorkingWithForms.html");//for url
		//user name
		driver.findElement(By.id("txtUserName")).sendKeys("ab");
			Thread.sleep(1000);
			
		//password
			driver.findElement(By.name("txtPwd")).sendKeys("a");
			Thread.sleep(1000);
			
         driver.findElement(By.className("Format")).sendKeys("a");
			
			Thread.sleep(1000);
			
    driver.findElement(By.cssSelector("input.Format1")).sendKeys("anamika");
			
			Thread.sleep(1000);
			
driver.findElement(By.name("txtLN")).sendKeys("bhadouriya");
			
			Thread.sleep(1000);
			
			//gender
     driver.findElement(By.cssSelector("input[value='Female']")).click();
			
			Thread.sleep(1000);
		//DOB	
     driver.findElement(By.name("DtOB")).sendKeys("10/05/1995");
			
			Thread.sleep(1000);
			//email
driver.findElement(By.name("Email")).sendKeys("anu@gmail.com");
			
			Thread.sleep(1000);
			//address
				driver.findElement(By.name("Address")).sendKeys("TilakNagar");
				Thread.sleep(1000);
			
			Select drpCity=new Select(driver.findElement(By.name("City")));
			//drpCity.selectByIndex(0);
			//drpCity.selectByVisibleText("Mumbai");
			drpCity.selectByIndex(2);
				
				driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("9999999999");
				
				
				List<WebElement> element=driver.findElements(By.name("chkHobbies"));
				
				for(WebElement val : element)
				{
					val.click();
					Thread.sleep(500);
				}
				
				
				/*String actualTitle;
				actualTitle=driver.getTitle();
				System.out.println("The page title is : " + actualTitle);
				String exceptedTitle="Email Registration Form";
				
				Boolean b=driver.getPageSource().contains("Email Registration Form");
				if(b==true)
				{
					System.out.println("Passed");
				}
				else {
					System.out.println("Failed");
				}
				
				String currentURL;
				currentURL=driver.getCurrentUrl();
				System.out.println("The page current URL is : "+currentURL);*/
				
				driver.findElement(By.name("submit")).click();
				driver.close();
				
				
				
				
				
				
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
	}
}
