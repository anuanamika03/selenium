import java.util.List;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class WorkingWithForms2 
{
	public static void main(String[] args) throws InterruptedException 
	{
		
		WebDriver driver=new FirefoxDriver();//for browser
		driver.get("file:///D:/Selenium%20html/registrationPage.html");//for url
		
		driver.findElement(By.name("firstName")).sendKeys("anamika");
			Thread.sleep(1000);
			
	
			driver.findElement(By.name("lastName")).sendKeys("bhadouriya");
			Thread.sleep(1000);
			
			driver.findElement(By.xpath("html/body/div/form/table/tbody/tr[3]/td[2]/input")).sendKeys("9999999999");
			Thread.sleep(1000);
		
            driver.findElement(By.name("emailId")).sendKeys("anu@gmail.com");
			Thread.sleep(1000);
			
           driver.findElement(By.name("password")).sendKeys("anu");
           Thread.sleep(1000);
           driver.findElement(By.name("reEnterpassword")).sendKeys("anu");
			Thread.sleep(1000);
		
			driver.findElement(By.cssSelector("input[value='female']")).click();
			Thread.sleep(1000);
			
			driver.findElement(By.cssSelector("input[value='email']")).click();
			Thread.sleep(1000);
			
			Select drpGraduation=new Select(driver.findElement(By.name("graduation")));
			//drpCity.selectByIndex(0);
			//drpCity.selectByVisibleText("Mumbai");
			drpGraduation.selectByIndex(2);
				
				String actualTitle;
				actualTitle=driver.getTitle();
				System.out.println("The page title is : " + actualTitle);
				String exceptedTitle="Registration Page";
				
				Boolean b=driver.getPageSource().contains("Registration Page");
				if(b==true)
				{
					System.out.println("Passed");
				}
				else {
					System.out.println("Failed");
				}
				
				String currentURL;
				currentURL=driver.getCurrentUrl();
				System.out.println("The page current URL is : "+currentURL);
				
				driver.findElement(By.name("Register")).click();
				driver.close();
				
				
				
				
				
				
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
	}
}
