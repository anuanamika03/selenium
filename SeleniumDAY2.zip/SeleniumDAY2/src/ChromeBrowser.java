import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ChromeBrowser {


		static String driverPath = "D:\\Users\\ADM-IG-HWDLAB2E\\Downloads\\New folder (3)D:\\Users\\ADM-IG-HWDLAB2E\\Downloads\\New folder (3)D:\\Users\\ADM-IG-HWDLAB2E\\Downloads\\New folder (3)D:\\Users\\ADM-IG-HWDLAB2E\\Downloads\\New folder (3)D:\\Users\\ADM-IG-HWDLAB2E\\Downloads\\New folder (3)D:\\Users\\ADM-IG-HWDLAB2E\\Downloads\\New folder (3)D:\\Users\\ADM-IG-HWDLAB2E\\Downloads\\New folder (3)D:\\Users\\ADM-IG-HWDLAB2E\\Downloads\\New folder (3)D:\\Users\\ADM-IG-HWDLAB2E\\Downloads\\New folder (3)D:\\Users\\ADM-IG-HWDLAB2E\\Downloads\\New folder (3)D:\\Users\\ADM-IG-HWDLAB2E\\Downloads\\New folder (3)D:\\Users\\ADM-IG-HWDLAB2E\\Downloads\\New folder (3)\\ChromeDriver\\";
		
		private WebDriver driver;
		
	
		@Before
		public void openBrowser() {
			//driver = new FirefoxDriver();
			System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
			driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		

		driver.get("http://demo.opencart.com/");
		
	}

}
